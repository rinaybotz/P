const modelsChatUsers = require('../database/chatUsers.js');
const { InlineKeyboard } = require("grammy");
const modelsUsers = require('../database/users.js');
const { addTime, cekTime } = require('../function/time.js');
 
let url = "google.com";

module.exports = async (bot, Users, ctx, from, chat, userName, sendMessage, setting, error, data) => {
  try {
    let user = await modelsUsers.findOne({ "id": data[2] });    
  
    if (data.length == 4){
      const newKeyboard = new InlineKeyboard().text("Sukses", "done");
      await ctx.editMessageText("User berhasil dilaporkan. Laporan ini sedang diproses, harap tidak menggunakan fitur laporan untuk tujuan yang tidak serius!", {
        reply_markup: newKeyboard,
      });
      if (user == null) return;       
      if (user.status.banned !== "false") return;
      await modelsUsers.updateOne({ id: data[2] }, { $addToSet: { report: from } }); 
      
      let gender = "🍎";
      if (user.gender == "cowok"){ gender = "🍏"; }
      
      const keyboard = new InlineKeyboard()
        .url(gender, `${url}?id=${data[3]}&report=${data[2]}`)
        .text("❌️", `laporkan#${data[1]}#${data[2]}#${data[3]}#no`)        
        .text("⭕️", `laporkan#${data[1]}#${data[2]}#${data[3]}#yes`);
      bot.api.sendMessage(from, "Users Report: " + data[2], {
        reply_markup: keyboard,
      });
    }    
    if (data.length == 5){    
      let gender = "🍎";
      if (user.gender == "cowok"){ gender = "🍏"; }
      
      if (user.status.banned !== "false") {
        const keyboard5 = new InlineKeyboard()        
          .url(gender, `${url}?id=${data[3]}&report=${data[2]}`)
          .text(`🔥`, `#`); 
        await ctx.editMessageText("Users Report: " + data[2], {
          reply_markup: keyboard5,
        });
        return;
      }
      if (data[4] == "no"){
        const keyboard2 = new InlineKeyboard().text("👍", `#`);
        await ctx.editMessageText("Users Report: " + data[2], {
          reply_markup: keyboard2,
        });
      }
      if (data[4] == "yes"){
        let gender = "🍎";
        if (user.gender == "cowok"){ gender = "🍏"; }
    
        const keyboard3 = new InlineKeyboard()        
          .url(gender, `${url}?id=${data[3]}&report=${data[2]}`)
          .text("3", `laporkan#${data[1]}#${data[2]}#${data[3]}#yes#3`)
          .text("7", `laporkan#${data[1]}#${data[2]}#${data[3]}#yes#7`)
          .text("30", `laporkan#${data[1]}#${data[2]}#${data[3]}#yes#30`)
          .text("365", `laporkan#${data[1]}#${data[2]}#${data[3]}#yes#365`); 
        await ctx.editMessageText("Users Report: " + data[2], {
          reply_markup: keyboard3,
        });
      }
    }
    if (data.length == 6){    
      let gender = "🍎";
      if (user.gender == "cowok"){ gender = "🍏"; }
    
      for (let i = 0; i < user.report.length; i++) {  
        if (data[1] !== setting.idAdmin){
          sendMessage({ to: data[1], text: "> Laporan diterima\nUser yang Anda laporkan sebelumnya terbukti melanggar peraturan bot\n\nTerima kasih atas kontribusi Anda dan sebagai apresiasi Anda mendapatkan paket premium selama 1 hari", parse: true });
          var user2 = await modelsUsers.findOne({ id: data[1] });
          await modelsUsers.updateOne({ id: data[1] }, { $set: { "status.premium": addTime(user2.status.premium, data[5] - 1 + 1) } });         
        }
      } 
      sendMessage({ to: data[2], text: "> Notifikasi\nTelah terdeteksi pelanggaran peraturan bot dari akunmu\n\nSebagai konsekuensinya kamu akan dibanned selama 15 hari", parse: true });          
      await modelsUsers.updateOne({ id: data[2] }, { $set: { report: [], "status.banned": addTime("false", data[5] - 1 + 1) } });      
      
      const keyboard4 = new InlineKeyboard()        
        .url(gender, `${url}?id=${data[3]}&report=${data[2]}`)
        .text(`Banned ${data[5]} Hari`, `#`); 
      await ctx.editMessageText("Users Report: " + data[2], {
        reply_markup: keyboard4,
      });
    }
 } catch(e){
    error(e);
  }
}
