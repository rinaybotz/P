const modelsUsers = require('../database/users.js');
const { addTime, cekTime } = require('../function/time.js');
 
module.exports = async (bot, Users, ctx, from, chat, userName, sendMessage, setting, error, data) => {
  try {
    if (Users !== null) {  
      ctx.deleteMessage().catch(e => { });  
      return sendMessage({ text: "Kamu sudah terdaftar sebelumnya\n> /menu : *Menampilkan menu bot*\n> /search : *Mencari teman baru*", parse: true });
    }
    
    ctx.deleteMessage().catch(e => { });
    
    if (data.length == 3){
      sendMessage({ text: "> Start\nSelanjutnya, Berapa umur kamu?", parse: true, button: [            
        [{ text: '10', callback_data: 'start#' + `${data[1]}#${data[2]}#10`},
        { text: '11', callback_data: 'start#' + `${data[1]}#${data[2]}#11`},
        { text: '12', callback_data: 'start#' + `${data[1]}#${data[2]}#12`},
        { text: '13', callback_data: 'start#' + `${data[1]}#${data[2]}#13`},
        { text: '14', callback_data: 'start#' + `${data[1]}#${data[2]}#14`}],                
        [{ text: '15', callback_data: 'start#' + `${data[1]}#${data[2]}#15`},
        { text: '16', callback_data: 'start#' + `${data[1]}#${data[2]}#16`},
        { text: '17', callback_data: 'start#' + `${data[1]}#${data[2]}#17`},
        { text: '18', callback_data: 'start#' + `${data[1]}#${data[2]}#18`},
        { text: '19', callback_data: 'start#' + `${data[1]}#${data[2]}#19`}],               
        [{ text: '20', callback_data: 'start#' + `${data[1]}#${data[2]}#20`},
        { text: '21', callback_data: 'start#' + `${data[1]}#${data[2]}#21`},
        { text: '22', callback_data: 'start#' + `${data[1]}#${data[2]}#22`},
        { text: '23', callback_data: 'start#' + `${data[1]}#${data[2]}#23`},
        { text: '24', callback_data: 'start#' + `${data[1]}#${data[2]}#24`}],                
        [{ text: '25', callback_data: 'start#' + `${data[1]}#${data[2]}#25`},
        { text: '26', callback_data: 'start#' + `${data[1]}#${data[2]}#26`},
        { text: '27', callback_data: 'start#' + `${data[1]}#${data[2]}#27`},
        { text: '28', callback_data: 'start#' + `${data[1]}#${data[2]}#28`},
        { text: '29', callback_data: 'start#' + `${data[1]}#${data[2]}#29`}]             
      ] });
    }    
    if (data.length == 4){
      sendMessage({ text: "Bot ini dengan tegas *melarang* konten pornografi Jika niat kamu adalah untuk hal tersebut lebih baik *jangan menggunakan bot ini*\n\n*Bergabunglah* dengan channel @MdSyncChannel bot untuk mendapatkan informasi terbaru tentang bot", parse: true, button: [            
        [{ text: 'Baik, Saya paham!', callback_data: 'start#' + `${data[1]}#${data[2]}#${data[3]}#true`}]
      ] });
    }
    if (data.length == 5){
      sendMessage({ text: "Semua selesai, Sekarang kamu dapat menggunakan bot ini\n> /search : *Mencari teman baru*", parse: true });
      const add = new modelsUsers({
        id: from,
        nama: userName,
        gender: data[2],
        chat: false,
        umur: data[3],
        medali: 0,
        like: 0,
        dislike: 0,    
        cmd: 0,  
        rating: 0,    
        bergabung: new Date(),  
        report: [],
        invite: [],
        status: {
          pin: false,
          banned: false,    
          premium: false
        },
        teman: {
          id: false,
          status: false,
          request: false
        },
        game: {
          play: false,
          giliran: false,
          playTime: false,
          nama: false,
          soal: 0,
          jawaban: false,
          query: false,
          pilihan: false    
        }
      });      
      await add.save();
      if (data[1] !== "false"){
        if (data[1] == `${from}`) return
        const UsersId = await modelsUsers.findOne({ id: data[1] });
        if (UsersId == null) return;
        sendMessage({ to: UsersId.id, text: "Seseorang bergabung menggunakan link invite kamu, Sebagai hadiah kami memberi kamu akses premium 1 Hari\n> /my : *Cek informasi tentang kamu*", parse: true });
        await modelsUsers.updateOne({ id: UsersId.id }, { 
          $set: { "status.premium": addTime(UsersId.status.premium, 1) }, 
          $addToSet: { invite: { $each: [from] } } 
        });
      }
    }        
  } catch(e){
    error(e);
  }
}
