const modelsUsers = require('../database/users.js');

module.exports = async (bot, Users, ctx, from, chat, query, message, command, userName, sendMessage, error) => {
  try {
    if (Users.teman.status == "true") return sendMessage({ text: "> Stop\nBot telah mencarikan kamu teman, Silahkan tunggu beberapa waktu", parse: true });
    if (Users.teman.status == "false") return sendMessage({ text: "> Stop\nKamu belum memiliki teman sebelumnya\n> /search : *Mencari teman baru*", parse: true });
      
    let sg = "cowok";    
    if (Users.gender == "cewek"){
      sg = "cewek";
    }
    
    await sendMessage({ to: Users.id, text: "> Next\nSukses Berhenti berteman", parse: true, button: [
      [{ text: 'Laporkan', callback_data: 'laporkan#' + from + `#${Users.teman.id}#${Users.chat}` }]
    ] });  
    setTimeout(() => {
      sendMessage({ text: "Mencari teman baru..."});
    }, 150);
    await sendMessage({ to: Users.teman.id, text: "Teman memutuskan pertemanan\n> /search : *Mencari teman baru*", parse: true, button: [
      [{ text: 'Laporkan', callback_data: 'laporkan#' + from + `#${Users.id}#${Users.chat}` }]
    ] });           
        
    await modelsUsers.updateOne({ id: Users.teman.id }, { $set: { "teman.status": "false", "teman.id": "false" } });
    await modelsUsers.updateOne({ id: from }, { $set: { "teman.status": "false", "teman.id": "false" } });      
 
    let allUsers = await modelsUsers.findOneAndUpdate({ "teman.status": "true", "teman.request": { $ne: sg }, "id": { $ne: from } }, { $set: { "teman.status": "berteman", "teman.id": from } }, { new: true });    
  
    if (allUsers == null){
      await modelsUsers.updateOne({ id: from }, { $set: { "teman.status": "true" } });    
    } else {
      let Teman = allUsers[Math.floor(Math.random() * allUsers.length)];
      if (Teman.teman.status == "berteman") {  
        if (Teman.teman.id !== `${from}`){     
          await modelsUsers.updateOne({ id: from }, { $set: { "teman.status": "true" } });
          return
        }
      }
      await sendMessage({ text: "Teman telah di temukan\n> /next : *Mencari teman lain*\n> /game : *Bermain game*\nAyo mulai mengobrol", parse: true });
      await sendMessage({ to: Teman.id, text: "Teman telah di temukan\n> /next : *Mencari teman lain*\n> /game : *Bermain game*\nAyo mulai mengobrol", parse: true });           
      await modelsUsers.updateOne({ id: from }, { $set: { "teman.status": "berteman", "teman.id": Teman.id } });
      await modelsUsers.updateOne({ id: Teman.id }, { $set: { "teman.status": "berteman", "teman.id": from } });      
      
      require('../sistem/addChatJson.js')(Users, Teman, error);
    }
    
  } catch(e){
    error(e);
  }
}