const _ = process.cwd();
const modelsUsers = require('../database/users.js');

module.exports = async (bot, Users, ctx, from, chat, query, message, command, userName, sendMessage, error) => {
  try {
    if (Users.teman.status == "true") return sendMessage({ text: "> Stop\nBot telah mencarikan kamu teman, Silahkan tunggu beberapa waktu", parse: true });
    if (Users.teman.status == "false") return sendMessage({ text: "> Stop\nKamu belum memiliki teman sebelumnya\n> /search : *Mencari teman baru*", parse: true });    
    
    await sendMessage({ text: "Sukses Berhenti berteman\n> /search : *Mencari teman baru*", parse: true, button: [
      [{ text: 'Laporkan', callback_data: 'laporkan#' + from + `#${Users.teman.id}#${Users.chat}` }]
    ] });
    await sendMessage({ to: Users.teman.id, text: "Teman memutuskan pertemanan\n> /search : *Mencari teman baru*", parse: true, button: [
      [{ text: 'Laporkan', callback_data: 'laporkan#' + Users.teman.id + `#${Users.id}#${Users.chat}` }]
    ] });           
        
    await modelsUsers.updateOne({ id: Users.teman.id }, { $set: { "teman.status": "false", "teman.id": "false" } });
    await modelsUsers.updateOne({ id: from }, { $set: { "teman.status": "false", "teman.id": "false" } });      
  } catch(e){
    error(e);
  }
}