module.exports = async (bot, Users, ctx, from, chat, query, message, command, userName, sendMessage, error) => {
  try {
    if (Users !== null) return sendMessage({ text: "Kamu sudah terdaftar sebelumnya\n> /menu : *Menampilkan menu bot*\n> /search : *Mencari teman baru*", parse: true });
    let id = false;
    
    if (query && query.length < 20){
      id = query.replace(/\D/g, '');
      if (id == ''){
        id = false;
      }
    }
      
    sendMessage({ text: "> Start\nHalo, silahkan pilih gender kamu", parse: true, button: [
      [{ text: 'Cowok', callback_data: 'start#' + id + '#cowok'},
      { text: 'Cewek', callback_data: 'start#' + id + '#cewek'}]
    ] });
    
  } catch(e){
    error(e);
  }
}