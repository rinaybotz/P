const mongoose = require('mongoose');

const SecretSchema = new mongoose.Schema({  
  id: String,
  date: String,
  chat: [{
    id: String,
    pesan: String
  }]
});

module.exports = mongoose.model('SecretV3-chat', SecretSchema);