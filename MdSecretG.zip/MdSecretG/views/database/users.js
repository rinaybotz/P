const mongoose = require('mongoose');

const SecretSchema = new mongoose.Schema({  
  id: String,
  nama: String,
  gender: String,
  chat: String,
  umur: Number,
  medali: Number,
  like: Number,
  dislike: Number,    
  cmd: Number,  
  rating: Number,    
  bergabung: String,  
  report: [String],
  invite: [String],
  status: {
    pin: String,
    banned: String,    
    premium: String
  },
  teman: {
    id: String,
    status: String,
    request: String
  },
  game: {
    play: String,
    giliran: String,
    playTime: String,
    nama: String,
    soal: Number,
    jawaban: String,
    query: String,
    pilihan: String    
  }
});

module.exports = mongoose.model('SecretV3', SecretSchema);
/*
await modelsUsers.updateOne(
  { id: id },  
  { 
    $set: { name: 'joko', umur: 12 },
    $inc: { score: 5 },
    $addToSet: { buah: { $each: ["apel", "anggur"] } }
  }
);
*/