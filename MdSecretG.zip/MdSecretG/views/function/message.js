module.exports = async (bot, ctx, from, chat, data) => {
  const to = data.to ? data.to : from;  
  const mark = {};
 
  if (data.reply){
    if (ctx.message.message_id){
      mark.reply_to_message_id = ctx.message.message_id;
    }
  }
  
  if (data.parse){
    mark.parse_mode = "MarkdownV2";
  }
  
  if (data.button){
    mark.reply_markup = { inline_keyboard: data.button };
  }
 
  if (data.text){
    bot.api.sendMessage(to, data.text, mark).then((message) => {
      if (data.timers){
        setTimeout(() => {        
          bot.api.deleteMessage(ctx.chat.id, message.message_id).catch(e => { console.log(e) });
        }, data.timers);
      }
    });
  }
}