module.exports.addTime = (time, number) => {
  try {  
    let result = "false";
    let myTime = time;
    
    let time1 = new Date();
    
    if (myTime == "false"){
      time1.setDate(time1.getDate() + number);
      result = time1;
    }
    if (myTime !== "false"){
      let time2 = new Date(myTime);
      
      if (time1 < time2){
        time2.setDate(time2.getDate() + number);
        result = time2;
      } else {
        time1.setDate(time1.getDate() + number);
        result = time1;
      }          
    }
    return result;    
  } catch(e) {
    console.log(e);
  }
}

module.exports.cekTime = (time) => {
  try {
    let result = "false";
    let myTime = time;
    
    let time1 = new Date();
    let time2 = new Date(myTime);
        
    if (time1 < time2){
      const timeDifference = time2 - time1;

      const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((timeDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((timeDifference % (1000 * 60 * 60)) / (1000 * 60));

      result = `${days} Hari, ${hours} Jam, ${minutes} Menit`;
    } 
    return result;
    
  } catch(e) {
    console.log(e);
  }
}
