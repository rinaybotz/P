const _ = process.cwd();
const modelsUsers = require('../database/users.js');
const modelsChatUsers = require('../database/chatUsers.js');
const fs = require('fs');
const deteksi = require('../dataJson/deteksi.json');

module.exports = async (bot, Users, ctx, from, chat, message, userName, sendMessage, setting, error) => {
  try {
    const x = setting.simbol;
    
    let Teman = await modelsUsers.findOne({ id: Users.teman.id });    
    
    if (Users.teman.id !== Teman.id || Teman.teman.id !== Users.id){
      sendMessage({ text: "Server kamu dengan teman bermasalah\n> /next : *Mencari teman lain*", parse: true});    
    }    
    const type = ctx.message.text ? "text" : ctx.message.sticker ? "sticker" : ctx.message.voice ? "voice" : ctx.message.audio ? "audio" : ctx.message.document ? "document" : ctx.message.video ? "video" : ctx.message.photo ? "photo" : "null";
    
    let g = {
      "danger": "-1002188503023",
      "warning": "-1002190346346",
      "media": "-1002249034012"
    };
    let gender = "🍎";
    if (Users.gender == "cowok"){ gender = "🍏"; }
    
    switch (type) {   
      case 'text': 
        try {                                        
          const message = ctx.message.text.toLowerCase();
          const messageArray = message.split(' ');
          
          
          const AddChatUsers =  await modelsChatUsers.findOneAndUpdate({ id: Users.chat }, { $push: { chat: { "id": `${from}`, "pesan": message } } }, { new: true });          
          if (AddChatUsers == null){
            require('../sistem/addChatJson.js')(Users, Teman, error);          
          }
          
          let mesum = [];
          let link = [];
          let promosi = [];
          let tag = [];
          
          for (let a = 0; a < messageArray.length; a++) {
            for (let b = 0; b < deteksi.mesum.length; b++) {
              if (messageArray[a].includes(deteksi.mesum[b])){
                mesum.push(messageArray[a]);
              }
            }
          }
          for (let a = 0; a < mesum.length; a++) {
            for (let b = 0; b < deteksi.nonMesum.length; b++) {
              if (deteksi.nonMesum[b].includes(mesum[a])){                
                mesum = mesum.filter(item => item !== mesum[a]);
              }
            }
          }
          
          for (let a = 0; a < messageArray.length; a++) {
            for (let b = 0; b < deteksi.link.length; b++) {
              if (messageArray[a].includes(deteksi.link[b])){
                link.push(messageArray[a]);
              }
            }
          }
          
          for (let a = 0; a < messageArray.length; a++) {
            for (let b = 0; b < deteksi.promosi.length; b++) {
              if (messageArray[a].includes(deteksi.promosi[b])){
                promosi.push(messageArray[a]);
              }
            }
          }
          
          for (let a = 0; a < messageArray.length; a++) {
            for (let b = 0; b < deteksi.tag.length; b++) {
              if (messageArray[a].includes(deteksi.tag[b])){
                tag.push(messageArray[a]);
              }
            }
          }
          
          if (mesum.length !== 0){                            
            await bot.api.sendMessage(from, "> Peringatan\nKata kata yang digunakan terdeteksi mengandung unsur pornografi\n\nMohon untuk tidak mengulanginya agar tidak berisiko terkena banned", { reply_to_message_id: ctx.message.message_id, parse_mode: "MarkdownV2" }).catch(e => error(e));
            await bot.api.sendMessage(g.danger, `${x} Message: ${message}\n${x} Deteksi: ${mesum}\n${x} From: ${from}`, { reply_markup: { inline_keyboard: [ [{ text: gender, callback_data: `banned#${from}#${setting.idAdmin}` } ] ] } }).catch(e => error(e));            
            return;
          }
          if (link.length !== 0){
            await bot.api.sendMessage(g.warning, `${x} Message: ${message}\n${x} Deteksi: ${link}\n${x} From: ${from}`, { reply_markup: { inline_keyboard: [ [{ text: gender, callback_data: `banned#${from}#${setting.idAdmin}` } ] ] } }).catch(e => error(e));            
          }
          if (promosi.length !== 0){                            
            await bot.api.sendMessage(from, "> Peringatan\nPromosi tidak diizinkan disini\n\nSilakan gunakan bot ini untuk mencari teman dan berinteraksi dengan baik", { reply_to_message_id: ctx.message.message_id, parse_mode: "MarkdownV2" }).catch(e => error(e));
            await bot.api.sendMessage(g.danger, `${x} Message: ${message}\n${x} Deteksi: ${promosi}\n${x} From: ${from}`, { reply_markup: { inline_keyboard: [ [{ text: gender, callback_data: `banned#${from}#${setting.idAdmin}` } ] ] } }).catch(e => error(e));            
            return;
          }
          if (tag.length !== 0){
            await bot.api.sendMessage(g.warning, `${x} Message: ${message}\n${x} Deteksi: ${tag}\n${x} From: ${from}`, { reply_markup: { inline_keyboard: [ [{ text: gender, callback_data: `banned#${from}#${setting.idAdmin}` } ] ] } }).catch(e => error(e));            
          }
          
          
          await bot.api.sendMessage(Teman.id, ctx.message.text).catch(e => error(e));
         
        } catch(e){ error(e) };    
      break;
    }
  } catch(e){
    error(e);
  }
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`);
  delete require.cache[file];
  require(file);
});
