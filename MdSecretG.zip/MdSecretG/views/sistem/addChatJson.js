const modelsChatUsers = require('../database/chatUsers.js');
const modelsUsers = require('../database/users.js');

const fs = require('fs');

module.exports = async (Users, Teman, error) => {
  try {
    function generateRandomString(length) {
      const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
      let result = '';
      for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        result += characters[randomIndex];
      }
      return result;
    }  
    const result = generateRandomString(10);
    const add = new modelsChatUsers({
      id: result,
      date: new Date(),
      chat: []
    });
    await add.save();
    await modelsUsers.updateOne({ id: Users.id }, { $set: { "chat": result } });
    await modelsUsers.updateOne({ id: Teman.id }, { $set: { "chat": result } });               
  } catch(e){
    error(e);
  }
}