const { Bot } = require('grammy');
const fs = require('fs');

const token = '7160645729:AAEshqwnZsuRqmaiWn_0nDZbeYvuUOajtGc';
const bot = new Bot(token);
let connections = false;

const setting = require('./views/admin/setting.json');
const modelsUsers = require('./views/database/users.js');
const { addTime, cekTime } = require('./views/function/time.js');
 
if (connections == false){
  require('./views/database/connection.js');
  connections = true;
}

bot.on('message', async (ctx) => {
  try {
    const from = ctx.update.message.from.id;  
    const chat = ctx.update.message.chat.id;
    const isBot = ctx.update.message.from.is_bot;  
    const userName = ctx.update.message.from.username; 
    const message = ctx.message.text ? ctx.message.text : ctx.message.caption ? ctx.message.caption : false;
    const isCommand = message ? ['/'].includes(message.charAt(0)) : false;
    const command = isCommand ? message.split(' ')[0].substring(1).toLowerCase() : false;
    const query = isCommand ? message.split(' ').slice(1).join(' ') : false;
    
    const Users = await modelsUsers.findOne({ id: from });
           
    function error(e){
      console.log(e);      
      ctx.reply(`Terjadi kesalahan, Jika kedepannya masih mengalami hal yang sama, Silahkan laporkan ke @${setting.admin}`).catch(e => { });
    }
    
    function sendMessage(data){
      require('./views/function/message.js')(bot, ctx, from, chat, data);
    } 
     
    if (Users == null){
      if (command !== "start"){
        return sendMessage({ text: "> Bot\nSilakan gunakan perintah /start terlebih dahulu untuk memulai bot ini", parse: true });
      }           
    }
    //console.log(new Date());
    if (Users !== null) {
      if (Users.status.banned !== "false"){      
        const cmdList = ["start","my","donasi"];
        if (!cmdList.includes(command)){
          const cekTimeBan = cekTime(Users.status.banned);
          if (cekTimeBan !== "false") return  ctx.reply("Klik [disini](https://t.me/MdSync) untuk menuju tautan.", {
            parse_mode: "Markdown",
          });
        }
      }
    }
    
    switch (command) {
      case 'start': case 'search': case 'stop': case 'next':
        require('./views/command/' + command + '.js')(bot, Users, ctx, from, chat, query, message, command, userName, sendMessage, error);
      break
    
      default:  
        if (Users.teman.status == "berteman"){
          require('./views/sistem/message.js')(bot, Users, ctx, from, chat, message, userName, sendMessage, setting, error);
        } else {
          sendMessage({ text: "Kamu belum memiliki teman\n> /search : *Mencari teman baru*", parse: true });
        }
      break    
    }
  } catch(e) {
    console.log(e);
    ctx.reply(`Terjadi kesalahan, Jika kedepannya masih mengalami hal yang sama, Silahkan laporkan ke @${setting.admin}`).catch(e => { });
  }
});

bot.on('callback_query', async (ctx) => {
  try {
    const data = ctx.callbackQuery.data.split('#');
    const command = data[0];
    
    const from = ctx.update.callback_query.from.id;  
    const chat = ctx.update.callback_query.message.chat.id;
    const userName = ctx.update.callback_query.from.username; 
    
    const Users = await modelsUsers.findOne({ id: from });
    
    function error(e){
      console.log(e);      
      ctx.reply(`Terjadi kesalahan, Jika kedepannya masih mengalami hal yang sama, Silahkan laporkan ke @${setting.admin}`).catch(e => { });
    }
    
    function sendMessage(dataz){
      require('./views/function/message.js')(bot, ctx, from, chat, dataz);
    }  
    if (Users == null){
      if (command !== "start"){
        return sendMessage({ text: "> Bot\nSilakan gunakan perintah /start terlebih dahulu untuk memulai bot ini", parse: true });
      }
    }
    
    
    switch (command) {
      case 'start': case 'laporkan':
        require('./views/callback/' + command + '.js')(bot, Users, ctx, from, chat, userName, sendMessage, setting, error, data);
      break
    }
    
  } catch(e) {
    console.log(e);
    ctx.reply(`Terjadi kesalahan, Jika kedepannya masih mengalami hal yang sama, Silahkan laporkan ke @${setting.admin}`).catch(e => { });
  }
});

bot.start();
require('./web.js');
console.log("Bot connect");

/*
const modelsUsers = require('./views/database/users.js');

const user = await modelsUsers.find({ });
//console.log(user.length);

const b = JSON.parse(fs.readFileSync('a.json', 'utf8'));


user.forEach(item => {
  if (!b.includes(item.id)) {
    console.log(item.id);
    b.push(item.id);
  }
});

fs.writeFileSync('a.json', JSON.stringify(b, null, 2), 'utf8');
*/