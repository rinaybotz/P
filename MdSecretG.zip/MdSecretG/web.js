const express = require('express')
const app = express()
const flash = require('connect-flash');
const port = process.env.PORT || 5000 || 3000

const modelsChatUsers = require('./views/database/chatUsers.js');

app.use(express.urlencoded({ extended: true }));
app.use(express.static("views"))
app.set('view engine', 'ejs');

app.use(flash());

app.get('/', async (req, res) => {
  try {
    if (!req.query.id) return res.send("Id undefined");    
    if (!req.query.report) return res.send("report undefined");
    const user = await modelsChatUsers.findOne({ id: req.query.id });
        
    if (user == null) return res.send("user undefined");
    
    let result = "";
        
    for (let i = 0; i < user.chat.length; i++) {
      if (user.chat[i].id == req.query.report){
        result += `<div class="chat1">
          <a>${user.chat[i].pesan}</a> 
          <a style="font-size: 10px; color: #BDBDBD;">${user.chat[i].id}</a>
        </div>`;        
      } else {
        result += `<div class="chat2">
          <a>${user.chat[i].pesan}</a> 
          <a style="font-size: 10px; color: #BDBDBD;">${user.chat[i].id}</a>
        </div>`;   
      }
    }
    res.render('website/home', { 
      result: result
    });  
  } catch(e){
    res.send("Terjadi kesalahan silahkan laporkan ke admin!");
  }
});

app.listen(port, () => {
  console.log(`app running at http://localhost:${port}`);
});